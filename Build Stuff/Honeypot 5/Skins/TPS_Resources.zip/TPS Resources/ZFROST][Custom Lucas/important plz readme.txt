the ice and fire pacs contains further aesthetic changes. replace the current *fitLucas* for this

the ice pac is for if you are only adding the blue skin.

skin works properly on slots 20-29
 
the aesthetic changes however only work on 27 for blue and 25-27 for the set

place the skins in the order of red>green>blue *e.g* fitlucas25red, 26 green, 27 blue






Thanks! <3