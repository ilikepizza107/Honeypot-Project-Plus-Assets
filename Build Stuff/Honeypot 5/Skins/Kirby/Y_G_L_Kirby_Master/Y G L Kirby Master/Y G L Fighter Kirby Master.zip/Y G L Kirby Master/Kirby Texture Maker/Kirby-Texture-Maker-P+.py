#!/usr/bin/env python

from gimpfu import *
import os
import time

def Kirby(infile, output, anger, skin, cheek, eye, iris, high, mouth, shoe, outpath, fs, ability, feather, beard, save):

    # Get image location
    image = pdb.gimp_xcf_load(0,infile,os.path.basename(infile))
    # Open image
    display = pdb.gimp_display_new(image)
    # Sets interpolation mode
    pdb.gimp_context_set_interpolation(3)

    # Fill skin layer
    pdb.gimp_context_set_foreground(skin)
    pdb.gimp_selection_all(image)
    pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Skin"),0,0,100,255,0,0,0)

    # Fill cheek
    pdb.gimp_context_set_foreground(cheek)
    pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Neutral Cheek (Feather 175, fill twice)"))
    pdb.gimp_selection_feather(image, 175)
    pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Cheek"),0,0,100,255,0,0,0)
    pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Cheek"),0,0,100,255,0,0,0)

    # Crop and scale cheek
    pdb.gimp_image_set_active_layer(image, pdb.gimp_image_get_layer_by_name(image, "Cheek"))
    pdb.plug_in_autocrop_layer(image, pdb.gimp_image_get_layer_by_name(image, "Cheek"))
    pdb.gimp_selection_none(image)
    pdb.gimp_item_transform_scale(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 321, 767, 1060, 1138)
    
    # Neutral
    if anger != 2:

        # Fill eye
        pdb.gimp_context_set_foreground(eye)
        pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Neutral Eye (feather 10)"))
        pdb.gimp_selection_feather(image, 10)
        pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye"),0,0,100,255,0,0,0)

        # Fill eye color
        pdb.gimp_context_set_foreground(iris)
        pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Neutral Eye Color (Shrink 10, Feather 100)"))
        pdb.gimp_selection_shrink(image, 10)
        pdb.gimp_selection_feather(image, 100)
        pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Color"),0,0,100,255,0,0,0)
        pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Color #1"),0,0,100,255,0,0,0)

        # Fill eye highlight
        pdb.gimp_context_set_foreground(high)
        pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Neutral Eye Highlight (Feather 20)"))
        pdb.gimp_selection_feather(image, 20)
        pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Highlight"),0,0,100,255,0,0,0)

    # Reset selection and active layer
    def reset ():
        pdb.gimp_selection_none(image)
        pdb.gimp_image_set_active_layer(image, pdb.gimp_image_get_layer_by_name(image, "Skin"))
    reset()

    # Angry Neutral
    if anger != 0:

        # Fill eye
        pdb.gimp_context_set_foreground(eye)
        pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Angry Neutral Eye (feather 10)"))
        pdb.gimp_selection_feather(image, 10)
        pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye copy #3"),0,0,100,255,0,0,0)

        # Fill eye color
        pdb.gimp_context_set_foreground(iris)
        pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Neutral Eye Color (Shrink 10, Feather 100)"))
        pdb.gimp_selection_shrink(image, 10)
        pdb.gimp_selection_feather(image, 100)
        pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Color copy #2"),0,0,100,255,0,0,0)
        pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Color #4"),0,0,100,255,0,0,0)

        # Fill eye highlight
        pdb.gimp_context_set_foreground(high)
        pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Neutral Eye Highlight (Feather 20)"))
        pdb.gimp_selection_feather(image, 20)
        pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Highlight copy #2"),0,0,100,255,0,0,0)

        reset()

    # If HD, export
    if output != 0:
        if anger != 2:
            layer = pdb.gimp_layer_new_from_visible(image, image, "Neutral Full")
            pdb.gimp_image_insert_layer(image, layer, None, -1)
            pdb.gimp_image_set_active_layer(image, layer)
            pdb.gimp_file_save(image, pdb.gimp_image_get_active_drawable(image), os.path.join(outpath, "Kirby_Neutral_HD.png"), "Kirby_Neutral_HD.png")
            pdb.gimp_image_remove_layer(image, layer)

        if anger != 0:
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Neutral"), 0)
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Angry Neutral"), 1)
            fighter = pdb.gimp_layer_new_from_visible(image, image, "Angry Full")
            pdb.gimp_image_insert_layer(image, fighter, None, -1)
            pdb.gimp_image_set_active_layer(image, fighter)
            pdb.gimp_file_save(image, pdb.gimp_image_get_active_drawable(image), os.path.join(outpath, "Kirby_Angry_Neutral_HD.png"), "Kirby_Angry_Neutral_HD.png")
            pdb.gimp_image_remove_layer(image, fighter)
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Neutral"), 1)
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Angry Neutral"), 0)

    if output == 2:
       
        if save:
            pdb.gimp_xcf_save(0, image, pdb.gimp_image_get_active_drawable(image), os.path.join(outpath, "Template_Neutral.xcf"), "Template_Neutral.xcf")
            
        pdb.gimp_context_set_default_colors()
        pdb.gimp_display_delete(display)
        
    else:
        def copy (layer, name):
            layer = pdb.gimp_layer_new_from_visible(image, image, name+" Full")
            pdb.gimp_image_insert_layer(image, layer, None, -1)
            pdb.gimp_drawable_set_visible(layer, 0)
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name), 0)
            return(layer)
        # Copy Neutral
        if anger != 2:
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Neutral"), 1)
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Angry Neutral"), 0)
            NFull = copy("NFull", "Neutral")

        # Copy Angry
        if anger != 0:
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Neutral"), 0)
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Angry Neutral"), 1)
            ANFull = copy("ANFull", "Angry Neutral")
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Angry Neutral"), 0)
        
        # Neutral
        if anger != 2:

            # Closed
            # Fill eye
            pdb.gimp_context_set_foreground(eye)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Closed Eye (Shrink 2, Feather 10) copy"))
            pdb.gimp_selection_shrink(image, 2)
            pdb.gimp_selection_feather(image, 10)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye copy #2"),0,0,100,255,0,0,0)

            reset()
            CFull = copy("CFull", "Closed")
            
            # Half
            # Fill eye
            pdb.gimp_context_set_foreground(eye)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Half Eye (Feather 10)"))
            pdb.gimp_selection_feather(image, 10)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye copy"),0,0,100,255,0,0,0)

            # Fill eye color
            pdb.gimp_context_set_foreground(iris)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Half Eye Color (Shrink 10, Feather 50) copy"))
            pdb.gimp_selection_shrink(image, 10)
            pdb.gimp_selection_feather(image, 50)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Color copy"),0,0,100,255,0,0,0)

            # Fill eye highlight
            pdb.gimp_context_set_foreground(high)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Half Eye Highlight (Feather 20) copy"))
            pdb.gimp_selection_feather(image, 20)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Highlight copy"),0,0,100,255,0,0,0)

            reset()
            HFull = copy("HFull", "Half")
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Half"), 0)

            # Damage
            
            # Disable normal cheek
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 0)
            
            # Fill blush
            pdb.gimp_context_set_foreground(cheek)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Damage Blush (Feather 200) copy"))
            pdb.gimp_selection_feather(image, 200)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Blush"),0,0,100,255,0,0,0)

            # Fill Cheek 1
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Damage Cheek 1 (Feather 100) copy"))
            pdb.gimp_selection_feather(image, 100)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Cheek 1"),0,0,100,255,0,0,0)

            # Fill Cheek 2
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Damage Cheek 2 copy"))
            pdb.gimp_selection_grow(image, 5)
            pdb.gimp_selection_feather(image, 40)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Cheek 2 (Grow 5, Feather 40)"),0,0,100,255,0,0,0)
            pdb.gimp_selection_none(image)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Damage Cheek 2 copy"))
            pdb.gimp_selection_shrink(image, 15)
            pdb.gimp_selection_feather(image, 30)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Cheek 2 (Shrink 15, Feather 30)"),0,0,100,255,0,0,0)
            
            # Fill eye
            pdb.gimp_context_set_foreground(eye)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Damage Eye (Feather 10) copy"))
            pdb.gimp_selection_feather(image, 10)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye #1"),0,0,100,255,0,0,0)

            # Fill eye color
            pdb.gimp_context_set_foreground(iris)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Damage Eye Color (Feather 100) copy"))
            pdb.gimp_selection_feather(image, 100)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Color #2"),0,0,100,255,0,0,0)

            # Fill eye highlight
            pdb.gimp_context_set_foreground(high)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Damage Eye Highlight (Feather 20) copy"))
            pdb.gimp_selection_feather(image, 20)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Highlight #1"),0,0,100,255,0,0,0)
            
            # Fill eye highlight 2
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Damage Eye Highlight 2 (Feather 10) copy"))
            pdb.gimp_selection_feather(image, 10)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Highlight 2"),0,0,100,255,0,0,0)

            reset()
            DFull = copy("DFull", "Damage")
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Damage"), 0)
            
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 1)
            
        # Angry
        if anger != 0:

            # Closed
            # Fill eye
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Angry Closed"), 1)
            pdb.gimp_context_set_foreground(eye)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Angry Closed Eye (Shrink 2, Feather 10) copy"))
            pdb.gimp_selection_shrink(image, 2)
            pdb.gimp_selection_feather(image, 10)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye copy #1"),0,0,100,255,0,0,0)

            reset()
            ACFull = copy("ACFull", "Angry Closed")

            # Half
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Angry Half"), 1)
            
            # Fill eye
            pdb.gimp_context_set_foreground(eye)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Angry Half Eye (feather 10)"))
            pdb.gimp_selection_feather(image, 10)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye copy #5"),0,0,100,255,0,0,0)

            # Fill eye color
            pdb.gimp_context_set_foreground(iris)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Half Eye Color (Shrink 10, Feather 50) copy"))
            pdb.gimp_selection_shrink(image, 10)
            pdb.gimp_selection_feather(image, 50)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Color copy #4"),0,0,100,255,0,0,0)

            # Fill eye highlight
            pdb.gimp_context_set_foreground(high)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Half Eye Highlight (Feather 20) copy"))
            pdb.gimp_selection_feather(image, 20)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Highlight copy #4"),0,0,100,255,0,0,0)

            reset()
            AHFull = copy("AHFull", "Angry Half")

            # Damage
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Angry Damage"), 1)
            
            # Disable normal cheek
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 0)
            
            # Fill blush
            pdb.gimp_context_set_foreground(cheek)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Damage Blush (Feather 200) copy"))
            pdb.gimp_selection_feather(image, 200)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Blush copy"),0,0,100,255,0,0,0)

            # Fill Cheek 1
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Damage Cheek 1 (Feather 100) copy"))
            pdb.gimp_selection_feather(image, 100)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Cheek 1 copy"),0,0,100,255,0,0,0)

            # Fill Cheek 2
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Damage Cheek 2 copy"))
            pdb.gimp_selection_grow(image, 5)
            pdb.gimp_selection_feather(image, 40)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Cheek 2 (Grow 5, Feather 40) copy"),0,0,100,255,0,0,0)
            pdb.gimp_selection_none(image)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Damage Cheek 2 copy"))
            pdb.gimp_selection_shrink(image, 15)
            pdb.gimp_selection_feather(image, 30)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Cheek 2 (Shrink 15, Feather 30) copy"),0,0,100,255,0,0,0)
            
            # Fill eye
            pdb.gimp_context_set_foreground(eye)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Angry Damage Eye (feather 10)"))
            pdb.gimp_selection_feather(image, 10)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye copy #4"),0,0,100,255,0,0,0)
        
            # Fill eye color
            pdb.gimp_context_set_foreground(iris)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Neutral Eye Color (Shrink 10, Feather 100)"))
            pdb.gimp_selection_shrink(image, 10)
            pdb.gimp_selection_feather(image, 100)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Color copy #3"),0,0,100,255,0,0,0)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Color #5"),0,0,100,255,0,0,0)

            # Fill eye highlight
            pdb.gimp_context_set_foreground(high)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Neutral Eye Highlight (Feather 20)"))
            pdb.gimp_selection_feather(image, 20)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Highlight copy #3"),0,0,100,255,0,0,0)
            
            # Fill eye highlight 2
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Angry Damage Eye Highlight 2 (feather 10)"))
            pdb.gimp_selection_feather(image, 10)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Eye Highlight 2 #1"),0,0,100,255,0,0,0)

            reset()
            ADFull = copy("ADFull", "Angry Damage")
            
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 1)

        # Creates new image for scaling
        image2 = pdb.gimp_image_new(1280, 1280, 0)
        display2 = pdb.gimp_display_new(image2)
        def paste (layer, name):
            layer = pdb.gimp_layer_new_from_drawable(layer, image2)
            pdb.gimp_image_add_layer(image2, layer, -1)
            return (layer)

        # Initializes lists
        layers = []
        names = []

        # Neutral
        if anger != 2:
            NFull = paste(NFull, "Neutral")
            HFull = paste(HFull, "Half")
            CFull = paste(CFull, "Closed")
            DFull = paste(DFull, "Damage")

            # Lists
            layers += [NFull, HFull, CFull, DFull]
            names += ["Neutral", "Half", "Closed", "Damage"]

        # Adds anger
        if anger != 0:
            ANFull = paste(ANFull, "Angry Neutral")
            AHFull = paste(AHFull, "Angry Half")
            ACFull = paste(ACFull, "Angry Closed")
            ADFull = paste(ADFull, "Angry Damage")
            layers += [ANFull, AHFull, ACFull, ADFull]
            names += ["Angry Neutral", "Angry Half", "Angry Closed", "Angry Damage"]

        # Scale, export, and close
        pdb.gimp_image_scale(image2, 128, 128)
        def export (layer, name):
            name = name.replace(" ", "_")
            pdb.gimp_image_set_active_layer(image2, layer)
            pdb.gimp_file_save(image2, pdb.gimp_image_get_active_drawable(image2), os.path.join(outpath, "Kirby_"+name+".png"), "Kirby_"+name+".png")
            pdb.gimp_drawable_set_visible(layer, 0)
        for x,y in zip(layers, names):
            export(x,y)
        pdb.gimp_display_delete(display2)

        # Neutral skin
        if anger != 2:
        
            # Creates image
            image3 = pdb.gimp_image_new(8, 8, 0)
            display3 = pdb.gimp_display_new(image3)
        
            # Creates new layer
            fill = pdb.gimp_layer_new(image3, 8, 8, 0, "Fill", 100, 0)
            pdb.gimp_image_add_layer(image3, fill, -1)
            pdb.gimp_image_set_active_layer(image3, fill)

            # Fills original
            pdb.gimp_context_set_foreground(skin)
            pdb.gimp_selection_all(image)
            pdb.gimp_edit_bucket_fill(fill, 0, 0, 100, 255, 0, 0, 0)
            pdb.gimp_selection_none(image)

            # Exports and closes
            pdb.gimp_image_set_active_layer(image3, fill)
            pdb.gimp_file_save(image3, pdb.gimp_image_get_active_drawable(image3), os.path.join(outpath, "Kirby_Skin.png"), "Kirby_Skin.png")
            pdb.gimp_display_delete(display3)

        # Anger skin
        if anger != 0:
        
            # Creates image
            image3 = pdb.gimp_image_new(256, 256, 0)
            display3 = pdb.gimp_display_new(image3)
        
            # Creates new layer
            fill = pdb.gimp_layer_new(image3, 256, 256, 0, "Fill", 100, 0)
            pdb.gimp_image_add_layer(image3, fill, -1)
            pdb.gimp_image_set_active_layer(image3, fill)

            # Fills original
            pdb.gimp_context_set_foreground(skin)
            pdb.gimp_selection_all(image)
            pdb.gimp_edit_bucket_fill(fill, 0, 0, 100, 255, 0, 0, 0)
            pdb.gimp_selection_none(image)
            
            # Moves hand wrap
            WrapL = pdb.gimp_layer_new_from_drawable(pdb.gimp_image_get_layer_by_name(image, "Hand Wrap"), image3)
            pdb.gimp_image_insert_layer(image3, WrapL, None, -1)
            pdb.gimp_drawable_set_visible(WrapL, 1)

            # Creates full skin
            SkinL = pdb.gimp_layer_new_from_visible(image3, image3, "Skin Full")
            pdb.gimp_image_insert_layer(image3, SkinL, None, -1)
            
            # Exports and closes
            pdb.gimp_image_set_active_layer(image3, SkinL)
            pdb.gimp_file_save(image3, pdb.gimp_image_get_active_drawable(image3), os.path.join(outpath, "Kirby_Skin_Fighter.png"), "Kirby_Skin_Fighter.png")
            pdb.gimp_display_delete(display3)
       
        # Creates mouth image
        image3 = pdb.gimp_image_new(96, 80, 0)
        display3 = pdb.gimp_display_new(image3)

        # Grey mouth
        if mouth == 0:
            mouthL = pdb.gimp_layer_new_from_drawable(pdb.gimp_image_get_layer_by_name(image, "Mouth"), image3)
            pdb.gimp_image_insert_layer(image3, mouthL, None, -1)

            # Exports
            pdb.gimp_image_set_active_layer(image3, mouthL)
            pdb.gimp_file_save(image3, pdb.gimp_image_get_active_drawable(image3), os.path.join(outpath, "Kirby_Mouth.png"), "Kirby_Mouth.png")

        else:
            mouthL = pdb.gimp_layer_new_from_drawable(pdb.gimp_image_get_layer_by_name(image, "Mouth Grey"), image3)
            pdb.gimp_image_insert_layer(image3, mouthL, None, -1)

            pdb.gimp_image_set_active_layer(image3, mouthL)
            pdb.gimp_file_save(image3, pdb.gimp_image_get_active_drawable(image3), os.path.join(outpath, "Kirby_Mouth.png"), "Kirby_Mouth.png")
            
        pdb.gimp_display_delete(display3)

        # Creates shoe image
        image3 = pdb.gimp_image_new(128, 64, 0)
        display3 = pdb.gimp_display_new(image3)
        ShoeL = pdb.gimp_layer_new(image3, 128, 64, 0, "Shoe", 100, 0)
        pdb.gimp_image_add_layer(image3, ShoeL, -1)

        # Fills shoe
        pdb.gimp_context_set_foreground(shoe)
        pdb.gimp_selection_all(image3)
        pdb.gimp_edit_bucket_fill(ShoeL,0,0,100,255,0,0,0)

        # Moves shoe value
        ShoeV = pdb.gimp_layer_new_from_drawable(pdb.gimp_image_get_layer_by_name(image, "Shoe Value"), image3)
        pdb.gimp_image_insert_layer(image3, ShoeV, None, -1)
        pdb.gimp_drawable_set_visible(ShoeV, 1)

        # Creates full shoe
        ShoeF = pdb.gimp_layer_new_from_visible(image3, image3, "Shoe Full")
        pdb.gimp_image_insert_layer(image3, ShoeF, None, -1)

        # Exports and closes
        pdb.gimp_image_set_active_layer(image3, ShoeF)
        pdb.gimp_file_save(image3, pdb.gimp_image_get_active_drawable(image3), os.path.join(outpath, "Kirby_Shoe.png"), "Kirby_Shoe.png")
        pdb.gimp_display_delete(display3)

        # Final Smash eyes if checked
        if fs:
            if not os.path.exists(outpath+"\Final Smash"):
                os.mkdir(outpath+"\Final Smash")
                
            def fs_export(name):
                # Creates new image
                image4 = pdb.gimp_image_new(1280, 1280, 0)
                display4 = pdb.gimp_display_new(image4)
                
                # Creates visible of face and fs eye in new image
                pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name+" Full"), 1)
                pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name+" FS"), 1)
                layer = pdb.gimp_layer_new_from_visible(image, image4, name+" Full FS")
                pdb.gimp_image_add_layer(image4, layer, -1)
                pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name+" Full"), 0)
                pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name+" FS"), 0)

                # Moves fs eye to new image, makes mask, and exports
                fseye = pdb.gimp_layer_new_from_drawable(pdb.gimp_image_get_layer_by_name(image, name+" FS"), image4)
                pdb.gimp_image_insert_layer(image4, fseye, None, -1)

                # Makes mask and scales
                mask = pdb.gimp_layer_create_mask(fseye, 2)
                pdb.gimp_layer_add_mask(layer, mask)
                pdb.gimp_image_remove_layer(image4, fseye)
                pdb.gimp_image_scale(image4, 128, 128)
                
                # Applies mask and exports
                pdb.gimp_layer_remove_mask(layer, 0)
                name = name.replace(" ", "_")
                pdb.file_tga_save(image4, layer, os.path.join(outpath+"\Final Smash", "Kirby_"+name+"_FS.tga"), "Kirby_"+name+"_FS.tga", 1, 0)
                pdb.gimp_display_delete(display4)
                
            for name in names:
                fs_export(name)

        # Copy abilities
        if ability:
            
            # Neutral skin
            if anger == 2:
            
                # Creates image
                image3 = pdb.gimp_image_new(8, 8, 0)
                display3 = pdb.gimp_display_new(image3)
            
                # Creates new layer
                fill = pdb.gimp_layer_new(image3, 8, 8, 0, "Fill", 100, 0)
                pdb.gimp_image_add_layer(image3, fill, -1)
                pdb.gimp_image_set_active_layer(image3, fill)

                # Fills original
                pdb.gimp_context_set_foreground(skin)
                pdb.gimp_selection_all(image)
                pdb.gimp_edit_bucket_fill(fill, 0, 0, 100, 255, 0, 0, 0)
                pdb.gimp_selection_none(image)

                # Exports and closes
                pdb.gimp_image_set_active_layer(image3, fill)
                pdb.gimp_file_save(image3, pdb.gimp_image_get_active_drawable(image3), os.path.join(outpath, "Kirby_Skin.png"), "Kirby_Skin.png")
                pdb.gimp_display_delete(display3)
            
            if not os.path.exists(outpath+"\Copy Abilities"):
                os.mkdir(outpath+"\Copy Abilities")
                
            pdb.gimp_context_set_foreground(skin)

            # Falco Face
            if not os.path.exists(outpath+"\Copy Abilities\Falco Face"):
                os.mkdir(outpath+"\Copy Abilities\Falco Face")
            def FalcoFace (name):
                
                # Creates new image
                image5 = pdb.gimp_image_new(1280, 1280, 0)
                display5 = pdb.gimp_display_new(image5)
                
                # Sets visibility
                pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name), 1)
                
                # New layer from visible
                layer = pdb.gimp_layer_new_from_visible(image, image5, "Falco "+name)
                pdb.gimp_image_add_layer(image5, layer, -1)

                # Scales, exports, and closes
                pdb.gimp_image_scale(image5, 128, 128)
                outname = name.replace(" ", "_")
                pdb.gimp_file_save(image5, pdb.gimp_image_get_active_drawable(image5), os.path.join(outpath+"\Copy Abilities\Falco Face", "Kirby_"+outname+"_Falco.png"), "Kirby_"+outname+"_Falco.png")
                pdb.gimp_display_delete(display5)
                pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name), 0)
                
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Falco Face #1"), 1)
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Falco Face #2"), 1)

            # Fills eye feathers
            pdb.gimp_context_set_foreground(feather)
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Falco"))
            pdb.gimp_selection_shrink(image, 100)
            pdb.gimp_selection_feather(image, 300)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Falco Face #1"),0,0,100,255,0,0,0)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Falco Face #1"),0,0,100,255,0,0,0)

            # Fills eye feathers 2
            pdb.gimp_image_select_item(image, 2, pdb.gimp_image_get_vectors_by_name(image, "Falco"))
            pdb.gimp_selection_shrink(image, 200)
            pdb.gimp_selection_feather(image, 100)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Falco Face #2"),0,0,100,255,0,0,0)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Falco Face #2"),0,0,100,255,0,0,0)
            pdb.gimp_context_set_foreground(skin)
            
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 1)
            if anger != 2:
                FalcoFace("Neutral")
                FalcoFace("Half")
                FalcoFace("Closed")
            if anger != 0:
                FalcoFace("Angry Neutral")
                FalcoFace("Angry Half")
                FalcoFace("Angry Closed")
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 0)
            if anger != 2:
                FalcoFace("Damage")
            if anger != 0:
                FalcoFace("Angry Damage")

            if fs:
                def fs_falco(name):
                    # Creates new image
                    image4 = pdb.gimp_image_new(1280, 1280, 0)
                    display4 = pdb.gimp_display_new(image4)
                    
                    # Creates visible of face and fs eye in new image
                    pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name), 1)
                    pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name+" FS"), 1)
                    layer = pdb.gimp_layer_new_from_visible(image, image4, name+" Falco FS")
                    pdb.gimp_image_add_layer(image4, layer, -1)
                    pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name+" FS"), 0)
    
                    # Moves fs eye to new image
                    fseye = pdb.gimp_layer_new_from_drawable(pdb.gimp_image_get_layer_by_name(image, name+" FS"), image4)
                    pdb.gimp_image_insert_layer(image4, fseye, None, -1)
    
                    # Makes mask and scales
                    mask = pdb.gimp_layer_create_mask(fseye, 2)
                    pdb.gimp_layer_add_mask(layer, mask)
                    pdb.gimp_image_remove_layer(image4, fseye)
                    pdb.gimp_image_scale(image4, 128, 128)
                
                    # Applies mask and exports
                    pdb.gimp_layer_remove_mask(layer, 0)
                    outname = name.replace(" ", "_")
                    pdb.file_tga_save(image4, layer, os.path.join(outpath+"\Copy Abilities\Falco Face", "Kirby_"+outname+"_Falco_FS.tga"), "Kirby_"+outname+"_Falco_FS.tga", 1, 0)
                    pdb.gimp_display_delete(display4)
                    pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name), 0)
                
                pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 1)
                if anger != 2:
                    fs_falco("Neutral")
                    fs_falco("Half")
                    fs_falco("Closed")
                if anger != 0:
                    fs_falco("Angry Neutral")
                    fs_falco("Angry Half")
                    fs_falco("Angry Closed")
                pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 0)
                if anger != 2:
                    fs_falco("Damage")
                if anger != 0:
                    fs_falco("Angry Damage")
                
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Falco Face #1"), 0)
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Falco Face #2"), 0)

            # Falco Head
            def ablty (w, h, name):

                # Creates new image
                image5 = pdb.gimp_image_new(w, h, 0)
                display5 = pdb.gimp_display_new(image5)

                # Creates and fills new layer
                pdb.gimp_context_set_foreground(skin)
                fill = pdb.gimp_layer_new(image5, w, h, 0, "Fill", 100, 0)
                pdb.gimp_image_add_layer(image5, fill, -1)
                pdb.gimp_image_set_active_layer(image5, fill)
                pdb.gimp_selection_all(image5)
                pdb.gimp_edit_bucket_fill(fill, 0, 0, 100, 255, 0, 0, 0)
                pdb.gimp_selection_none(image5)

                # Moves texture to new image
                texture = pdb.gimp_layer_new_from_drawable(pdb.gimp_image_get_layer_by_name(image, name), image5)
                pdb.gimp_image_insert_layer(image5, texture, None, -1)

                # Makes visible and makes it active
                pdb.gimp_drawable_set_visible(texture, 1)
                full = pdb.gimp_layer_new_from_visible(image5, image5, "Full")
                pdb.gimp_image_insert_layer(image5, full, None, -1)

                # Exports and closes
                pdb.gimp_image_set_active_layer(image5, full)
                if name == "Snake Beard":
                    pdb.gimp_image_scale(image5, 128, 128)
                name = name.replace(" ","_")
                pdb.gimp_file_save(image5, pdb.gimp_image_get_active_drawable(image5), os.path.join(outpath+"\Copy Abilities", "Kirby_"+name+".png"), "Kirby_"+name+".png")
                pdb.gimp_display_delete(display5)

            ablty(256,256,"Falco Head")

            # Snake Face
            if not os.path.exists(outpath+"\Copy Abilities\Snake Face"):
                os.mkdir(outpath+"\Copy Abilities\Snake Face")
                
            def SnakeFace (name):
                
                # Creates new image
                image5 = pdb.gimp_image_new(1280, 1280, 0)
                display5 = pdb.gimp_display_new(image5)
                
                # Sets visibility
                pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name), 1)
                
                # New layer from visible
                layer = pdb.gimp_layer_new_from_visible(image, image5, "Snake "+name)
                pdb.gimp_image_add_layer(image5, layer, -1)

                # Scales, exports, and closes
                pdb.gimp_image_scale(image5, 128, 128)
                outname = name.replace(" ", "_")
                pdb.gimp_file_save(image5, pdb.gimp_image_get_active_drawable(image5), os.path.join(outpath+"\Copy Abilities\Snake Face", "Kirby_"+outname+"_Snake.png"), "Kirby_"+outname+"_Snake.png")
                pdb.gimp_display_delete(display5)
                pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name), 0)           

            # Fills beard
            pdb.gimp_context_set_foreground(beard)
            pdb.gimp_selection_all(image)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Snake Face"),0,0,100,255,0,0,0)
            pdb.gimp_edit_bucket_fill(pdb.gimp_image_get_layer_by_name(image, "Snake Beard"),0,0,100,255,0,0,0)
            
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Snake Face"), 1)
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 1)
            
            # Moves layers
            pdb.gimp_layer_set_offsets(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 271, 767)
            for name in names:
                pdb.gimp_layer_set_offsets(pdb.gimp_image_get_layer_by_name(image, name), -50, 0)
            pdb.gimp_layer_set_offsets(pdb.gimp_image_get_layer_by_name(image, "Damage"), -50, 0)
            
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 1)
            if anger != 2:
                SnakeFace("Neutral")
                SnakeFace("Half")
                SnakeFace("Closed")
            if anger != 0:
                SnakeFace("Angry Neutral")
                SnakeFace("Angry Half")
                SnakeFace("Angry Closed")
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 0)
            if anger != 2:
                SnakeFace("Damage")
            if anger != 0:
                SnakeFace("Angry Damage")

            if fs:
                def fs_snake(name):
                    # Creates new image
                    image4 = pdb.gimp_image_new(1280, 1280, 0)
                    display4 = pdb.gimp_display_new(image4)
                    
                    # Creates visible of face and fs eye in new image
                    pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name), 1)
                    pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name+" FS"), 1)
                    layer = pdb.gimp_layer_new_from_visible(image, image4, name+" Snake FS")
                    pdb.gimp_image_add_layer(image4, layer, -1)
                    pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name+" FS"), 0)
    
                    # Moves fs eye to new image
                    fseye = pdb.gimp_layer_new_from_drawable(pdb.gimp_image_get_layer_by_name(image, name+" FS"), image4)
                    pdb.gimp_image_insert_layer(image4, fseye, None, -1)
                    pdb.gimp_layer_set_offsets(fseye, -50, 0)
                    pdb.gimp_layer_resize_to_image_size(fseye)
    
                    # Makes mask and scales
                    mask = pdb.gimp_layer_create_mask(fseye, 2)
                    pdb.gimp_layer_add_mask(layer, mask)
                    pdb.gimp_image_remove_layer(image4, fseye)
                    pdb.gimp_image_scale(image4, 128, 128)
                
                    # Applies mask and exports
                    pdb.gimp_layer_remove_mask(layer, 0)
                    outname = name.replace(" ", "_")
                    pdb.file_tga_save(image4, layer, os.path.join(outpath+"\Copy Abilities\Snake Face", "Kirby_"+outname+"_Snake_FS.tga"), "Kirby_"+outname+"_Snake_FS.tga", 1, 0)
                    pdb.gimp_display_delete(display4)
                    pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, name), 0)

                pdb.gimp_layer_set_offsets(pdb.gimp_image_get_layer_by_name(image, "Final Smash"), -50, 0)
                pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 1)
                if anger != 2:
                    fs_snake("Neutral")
                    fs_snake("Half")
                    fs_snake("Closed")
                if anger != 0:
                    fs_snake("Angry Neutral")
                    fs_snake("Angry Half")
                    fs_snake("Angry Closed")
                pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 0)
                if anger != 2:
                    fs_snake("Damage")
                if anger != 0:
                    fs_snake("Angry Damage")

            pdb.gimp_layer_set_offsets(pdb.gimp_image_get_layer_by_name(image, "Final Smash"), 0, 0)
            pdb.gimp_layer_set_offsets(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 321, 767)
            for name in names:
                pdb.gimp_layer_set_offsets(pdb.gimp_image_get_layer_by_name(image, name), 0, 0)
            pdb.gimp_layer_set_offsets(pdb.gimp_image_get_layer_by_name(image, "Damage"), 0, 0)
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Snake Face"), 0)

            # DK A
            ablty(64,128,"DK A")

            # DK B
            ablty(128,256,"DK B")

            # DK Anger Skin
            if anger != 0:
            
                # Creates image
                image3 = pdb.gimp_image_new(256, 256, 0)
                display3 = pdb.gimp_display_new(image3)
            
                # Creates new layer
                fill = pdb.gimp_layer_new(image3, 256, 256, 0, "Fill", 100, 0)
                pdb.gimp_image_add_layer(image3, fill, -1)
                pdb.gimp_image_set_active_layer(image3, fill)

                # Fills original
                pdb.gimp_context_set_foreground(skin)
                pdb.gimp_selection_all(image)
                pdb.gimp_edit_bucket_fill(fill, 0, 0, 100, 255, 0, 0, 0)
                pdb.gimp_selection_none(image)

                # Moves DK fur
                FurL = pdb.gimp_layer_new_from_drawable(pdb.gimp_image_get_layer_by_name(image, "DK Skin"), image3)
                pdb.gimp_image_insert_layer(image3, FurL, None, -1)
                pdb.gimp_drawable_set_visible(FurL, 1)
                
                # Moves hand wrap
                WrapL = pdb.gimp_layer_new_from_drawable(pdb.gimp_image_get_layer_by_name(image, "Hand Wrap"), image3)
                pdb.gimp_image_insert_layer(image3, WrapL, None, -1)
                pdb.gimp_drawable_set_visible(WrapL, 1)

                # Creates full skin
                SkinL = pdb.gimp_layer_new_from_visible(image3, image3, "Skin Full")
                pdb.gimp_image_insert_layer(image3, SkinL, None, -1)

                # Scales, exports, and closes
                pdb.gimp_image_scale(image3, 128, 128)
                pdb.gimp_image_set_active_layer(image3, SkinL)
                pdb.gimp_file_save(image3, pdb.gimp_image_get_active_drawable(image3), os.path.join(outpath+"\Copy Abilities", "Kirby_DK_Skin_Fighter.png"), "Kirby_DK_Skin_Fighter.png")
                pdb.gimp_display_delete(display3)

            # Jigglypuff
            ablty(64,128,"Jigglypuff")

            # Snake Beard
            ablty(1280,1280,"Snake Beard")

        # Deletes full layers
        for name in names:
            pdb.gimp_image_remove_layer(image, pdb.gimp_image_get_layer_by_name(image, name+" Full"))

        # Saves if checked
        if save:

            # Reset and save
            reset()
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Cheek"), 1)
            pdb.gimp_drawable_set_visible(pdb.gimp_image_get_layer_by_name(image, "Neutral"), 1)
            pdb.gimp_xcf_save(0, image, pdb.gimp_image_get_active_drawable(image), os.path.join(outpath, "Template_Complete.xcf"), "Template_Complete.xcf")

        # Closes all images
        pdb.gimp_context_set_default_colors()
        pdb.gimp_display_delete(display)

    return

register(
    "python-fu-PPlus-KIRBY-TEXTURE-MAKER",
    "Make all of Kirby's face textures plus his foot texture.\n\nWARNING: Files exported from this plugin will overwrite already existing files with the same name in the output folder",
    "Takes colors from the user and completes the steps to make Kirby's textures using the Kirby Consistency Project",
    "MetalLegacy", "MetalLegacy", "2021",
    "P+ Kirby Texture Maker",
    "",
    [
        (PF_FILE, "infile", "Select Plugin Template.xcf", None),
        (PF_RADIO, "output", "Face Output Scale", 0,
            (
                ("SD Only", 0),
                ("SD & HD Neutral", 1),
                ("HD Neutral Only", 2)
            )
         ),
        (PF_RADIO, "anger", "Include Fighter Kirby Angry Eyes?", 0,
            (
                ("No (Normal Only)", 0),
                ("Yes (Normal and Angry)", 1),
                ("Only (Angry Only)", 2)
            )
         ),
        (PF_COLOR, "skin", "Skin Color", (181,125,140)),
        (PF_COLOR, "cheek", "Cheek Color", (178,75,126)),
        (PF_COLOR, "eye", "Eye Base Color \n(recommended don't change)", (0,0,0)),
        (PF_COLOR, "iris", "Iris Color", (22,50,131)),
        (PF_COLOR, "high", "Eye Highlight Color \n(recommended don't change)", (216,217,216)),
        (PF_RADIO, "mouth", "Mouth Color", 0,
            (
                ("Default", 0),
                ("Greyscale", 1),
            )
         ),
        (PF_COLOR, "shoe", "Shoe Color", (134,55,31)),
        (PF_DIRNAME, "outpath", "Output Folder", "/tmp"),
        (PF_BOOL,   "fs", "Include Final Smash Eyes?", False),
        (PF_BOOL,   "ability", "Include Copy Abilities?", False),
        (PF_COLOR, "feather", """Falco Eye "Feather" Color \n(recommended don't change)""", (167,57,60)),
        (PF_COLOR, "beard", """Snake Beard Color \n(recommended don't change)""", (74,46,25)),
        (PF_BOOL,   "save", "Save Completed Template?", False),
    ],
    [],
    Kirby, menu="<Toolbox>/Tools")

main()
