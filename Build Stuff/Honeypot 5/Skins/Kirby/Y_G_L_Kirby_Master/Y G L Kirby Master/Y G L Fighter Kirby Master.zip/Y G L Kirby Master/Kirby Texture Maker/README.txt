THIS ONLY WORKS PROPERLY WITH GIMP 2.8, IT WILL NOT CREATE THE CORRECT RESULT IN 2.10.  IF YOU HAVE GIMP 2.10 INSTALLED PLEASE USE THE INCLUDED PORTABLE INSTALLER

To install:

1. Install Gimp via the installer.
2. Copy the Kirby-Texture-Maker.py files.
3. Go to your user folder (usually C:\Users\[USER]) and find a folder called .gimp-2.8. For portable GIMP use "App\gimp\lib\gimp\2.0\plug-ins"
4. Find the "plug-ins" folder. 
5. Paste the file you copied earlier.

To use:

1. Open Gimp 2.8.  If it is already open, close and reopen it.
2. Go to Tools, where you will see "Kirby Texture Maker" near the bottom of the list.
3. Click it, change settings as desired, and click "OK"

If there are any problems, reach me at MetalLegacy#8816 on Discord

Skin fa6417
Cheek d65d21
Eye e89d5a
Shoe 423531

